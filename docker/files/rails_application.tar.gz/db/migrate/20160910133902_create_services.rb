class CreateServices < ActiveRecord::Migration
  def change
    create_table :services do |t|
      t.integer :account_id, null: false
      t.string  :name,   null: false
      t.string  :code,   null: false
      t.string  :description
      t.timestamps null: false
    end

    # create_table :networks_services, id: false do |t|
    #     t.belongs_to :network, index: true
    #     t.belongs_to :service, index: true
    # end

    create_table :networks_services, id: false do |t|
      t.column :network_id, :integer
      t.column :service_id, :integer
    end
    
    
    # create_table :groups_roles, {:id => false} do |t|
    #   t.column :role_id, :integer
    #   t.column :group_id, :integer
    # end
    
    create_table :machines_services, id: false do |t|
        t.column :machine_id, :integer
        t.column :service_id, :integer
    end
    
  end
end
