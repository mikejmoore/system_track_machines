class CreateMachines < ActiveRecord::Migration
  def change
    create_table :machines do |t|
      t.integer :account_id
      t.integer :network_id
      t.string  :name,   null: false
      t.string  :code,   null: false
      t.string  :status,   null: false
      t.string  :ip_address
      t.string  :dns_name
      t.string  :code
      t.decimal :price, :precision => 8, :scale => 2
      t.datetime :purchase_date
      t.datetime :activation_date
      t.timestamps null: false
    end
    
    create_table :tags do |t|
      t.integer :account_id
      t.string  :object_type, null: false
      t.string  :code,            null: false
      t.string  :name
      t.timestamps null: false
    end
    
    create_table :machine_tags do |t|
      t.integer :machine_id,  null: false
      t.integer :tag_id,      null: false
    end
    
    create_table :machine_network_interfaces do |t|
      t.integer :machine_id
      t.integer :network_id
      t.string  :mac_address
      t.string  :code
      t.integer :dhcp
    end
    
  end
end
