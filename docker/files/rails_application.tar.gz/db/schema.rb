# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160910133902) do

  create_table "machine_network_interfaces", force: :cascade do |t|
    t.integer "machine_id",  limit: 4
    t.integer "network_id",  limit: 4
    t.string  "mac_address", limit: 255
    t.string  "code",        limit: 255
    t.integer "dhcp",        limit: 4
  end

  create_table "machine_tags", force: :cascade do |t|
    t.integer "machine_id", limit: 4, null: false
    t.integer "tag_id",     limit: 4, null: false
  end

  create_table "machines", force: :cascade do |t|
    t.integer  "account_id",      limit: 4
    t.integer  "network_id",      limit: 4
    t.string   "name",            limit: 255,                         null: false
    t.string   "code",            limit: 255
    t.string   "status",          limit: 255,                         null: false
    t.string   "ip_address",      limit: 255
    t.string   "dns_name",        limit: 255
    t.decimal  "price",                       precision: 8, scale: 2
    t.datetime "purchase_date"
    t.datetime "activation_date"
    t.datetime "created_at",                                          null: false
    t.datetime "updated_at",                                          null: false
  end

  create_table "machines_services", id: false, force: :cascade do |t|
    t.integer "machine_id", limit: 4
    t.integer "service_id", limit: 4
  end

  create_table "networks", force: :cascade do |t|
    t.integer  "account_id",      limit: 4,                           null: false
    t.string   "name",            limit: 255,                         null: false
    t.string   "code",            limit: 255,                         null: false
    t.string   "status",          limit: 255,                         null: false
    t.string   "address",         limit: 255
    t.string   "mask",            limit: 255
    t.string   "gateway",         limit: 255
    t.decimal  "price",                       precision: 8, scale: 2
    t.datetime "activation_date"
    t.datetime "created_at",                                          null: false
    t.datetime "updated_at",                                          null: false
  end

  create_table "networks_services", id: false, force: :cascade do |t|
    t.integer "network_id", limit: 4
    t.integer "service_id", limit: 4
  end

  create_table "services", force: :cascade do |t|
    t.integer  "account_id",  limit: 4,   null: false
    t.string   "name",        limit: 255, null: false
    t.string   "code",        limit: 255, null: false
    t.string   "description", limit: 255
    t.datetime "created_at",              null: false
    t.datetime "updated_at",              null: false
  end

  create_table "tags", force: :cascade do |t|
    t.integer  "account_id",  limit: 4
    t.string   "object_type", limit: 255, null: false
    t.string   "code",        limit: 255, null: false
    t.string   "name",        limit: 255
    t.datetime "created_at",              null: false
    t.datetime "updated_at",              null: false
  end

end
