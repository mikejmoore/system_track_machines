
class Machine < ActiveRecord::Base
  include MachineLogic
  belongs_to :account
  belongs_to :network
  has_and_belongs_to_many :services #, autosave: true, join_table: 'machines_services'
end
