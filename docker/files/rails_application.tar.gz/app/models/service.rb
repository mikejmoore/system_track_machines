
class Service < ActiveRecord::Base
  include ServiceLogic
  # has_many :networks, through: 'networks_services'
  # has_many :machines, through: 'machines_services'
  
  has_and_belongs_to_many :networks, autosave: true
  has_and_belongs_to_many :machines, autosave: true
end
