
class Network < ActiveRecord::Base
  include NetworkLogic
  has_many :machines
  has_and_belongs_to_many :services, autosave: true, join_table: 'networks_services'
  belongs_to :account
end
