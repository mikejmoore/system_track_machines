
class MachineNetworkInterface < ActiveRecord::Base
  belongs_to :machine
end
