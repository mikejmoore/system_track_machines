require_relative "./base_controller"

module Api
  module V1

    class ServicesController < V1::BaseController
      #before_filter :user_from_params

      def index
        account_id = @user.account_id.to_i
        account_id = params[:account_id].to_i if (params[:account_id]) 
        if (@user.account_id != account_id) && (!@user.is_super_user?)
          render text: "User (@user.email) does not have permission to networks on account: #{account_id}", status: 403
        else
          services = Service.where(account_id: account_id)
          if (services == nil)
            render text: [].to_json
          else
            render text: services.to_json(:include=> [:networks, :machines])
          end
        end
        
      end
      
      def create
        service_json = params[:service]
        account_id = @user.account_id.to_i
        service = nil
        if (service_json[:id])
          service = Service.find(service_json[:id].to_i)
        else
          service = Service.new
        end
        
        service.account_id = account_id
        service.name = service_json[:name]
        service.code = service_json[:code]
        service.description = service_json[:description]
        
        
        service.machines.clear
        params[:service].keys.each do |key|
          if (key.to_s.start_with? "machine_")
            machine_id = key.split('_').last.to_i
            service.machines << Machine.find(machine_id)
          end
        end
        service.save!
        render text: service.to_json(:include=> [:networks, :machines])
      end
   
      def get
        service_id = params[:service_id].to_i
        render text: Service.find(service_id).to_json(:include => [:networks, :machines])
      end
  
      def status_list
        list = []
        Service::STATUS.keys.each do |key|
          list << {code: key.to_s, name: Service::STATUS[key]}
        end
        render text: list.to_json
      end
  
      def add_to_network
        network_id = params[:network_id]
        service_id = params[:service_id]
        service = Service.find(service_id.to_i)
        network = Network.find(network_id.to_i)
        service.networks << network if (!service.networks.include? network)
        service.save!
        render text: service.to_json(:include=> [:networks, :machines])
      end

      def remove_from_network
        network_id = params[:network_id]
        service_id = params[:service_id]
        service = Service.find(service_id.to_i)
        network = Network.find(network_id.to_i)
        service.networks.delete(network) if (service.networks.include? network)
        service.save!
        render text: service.to_json(:include=> [:networks, :machines])
      end

      def add_to_machine
        machine_id = params[:machine_id]
        service_id = params[:service_id]
        service = Service.find(service_id.to_i)
        machine = Machine.find(machine_id.to_i)
        service.machines << machine if (!service.machines.include? machine)
        service.save!
        render text: service.to_json(:include=> [:networks, :machines])
      end
      
      def remove_from_machine
        machine_id = params[:machine_id]
        service_id = params[:service_id]
        service = Service.find(service_id.to_i)
        machine = Network.find(network_id.to_i)
        service.machines.delete(machine) if (service.machines.include? machine)
        service.save!
        render text: service.to_json(:include=> [:networks, :machines])
      end
  
    end
    
  end
end