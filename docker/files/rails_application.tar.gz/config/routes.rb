Rails.application.routes.draw do
  get "/api/v1/machines/index"
  get "/api/v1/machines/get"
  post "/api/v1/machines/create"
  get "/api/v1/machines/status_list"
  get "/api/v1/machines/ansible_hosts"

  get "/api/v1/networks/index"
  get "/api/v1/networks/get"
  post "/api/v1/networks/create"
  post '/test/reset', to: 'api/tests#reset'
  get "/api/v1/networks/status_list"

  get "/api/v1/services/index"
  get "/api/v1/services/get"
  post "/api/v1/services/create"
  get "/api/v1/services/status_list"
  
  put "/api/v1/services/add_to_network"
  delete "/api/v1/services/remove_from_network"

  put "/api/v1/services/add_to_machine"
  delete "/api/v1/services/remove_from_machine"
  
  get "/api/v1/tags/index"
  post "/api/v1/tags/create"
  
end


