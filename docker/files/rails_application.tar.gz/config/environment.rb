#require_relative "../../system_track_shared_gem/lib/system_track_shared"
require 'system_track_shared'

# Load the Rails application.
require File.expand_path('../application', __FILE__)

# Initialize the Rails application.
Rails.application.initialize!
