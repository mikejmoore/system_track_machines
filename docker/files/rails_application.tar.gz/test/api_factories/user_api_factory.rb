
class UserApiFactory
  def random_user(account_hash)
      # account                { FactoryGirl.create :account }
      # name                   { "#{RandomWord.adjs.next} #{RandomWord.nouns.next}" }
      # email                  { "#{name.split(' ').join('.')}@corp.com" }
      # #uid:                   { email }
      # plain_password         { "secret123" }
      # password               { User.new.send(:password_digest, plain_password) }
      # password_confirmation  { password }
      # nickname               { RandomWord.nouns.next }
      # confirmed_at           { Time.now }
   # }
    
  end
  
end