require_relative '../spec_helper'


describe "Services", :type => :api do
  # let!(:user)  { {} }
  # let!(:service)  { FactoryGirl.create :service, account: user.account }
  #
  # let!(:other_account) { FactoryGirl.create :account }
  # let!(:other_service)  { FactoryGirl.create :service, account: other_account }
  

  context "Find service information" do
    
    it "Can find my services" do
      session = {}
      user = unregistered_user
      user = UserObject.new(UserService.new.register(session, {user: user}))
      
      credentials = session[:credentials]
      service_hashes = []
      (1..3).each do
        service = service_hash(user['account_id'])
        service_hashes << service
        response = post "/api/v1/services/create", {service: service, credentials: session[:credentials]}
        expect(response.status).to eq 200
        service_back = JSON.parse(response.body)
      end
      
      response = get "/api/v1/services/index", {account_id: user.account_id, credentials: session[:credentials]}
      expect(response.status).to eq 200
      services_json = JSON.parse(response.body)
      expect(services_json.length).to eq service_hashes.length
      
      UserService.new.logoff(session)
      response = get "/api/v1/services/index", {credentials: credentials}
      expect(response.status).to eq 401
    end
    
    it "Cannot see other accounts services" do
      session = {}
      other_user = unregistered_user
      other_user = UserObject.new(UserService.new.register(session, {user: other_user}))
      (1..2).each do
        service = service_hash(other_user.account_id)
        post "/api/v1/services/create", {service: service, credentials: session[:credentials]}
      end
      
      user = unregistered_user
      user = UserObject.new(UserService.new.register(session, {user: user}))
      expect(other_user['account_id']).to_not eq user.account_id

      response = get "/api/v1/services/index", {account_id: other_user.account_id, credentials: user.credentials}
      expect(response.status).to eq 403
    end
    
    it "Super user can see any account's services'" do
      session = {}
      other_user = unregistered_user
      other_user = UserObject.new(UserService.new.register(session, {user: other_user}))
      (1..2).each do
        service = service_hash(other_user.account_id)
        post "/api/v1/services/create", {service: service, credentials: other_user.credentials}
      end
      
      super_user = UserObject.new(UserService.new.sign_in(session, TestConstants::SUPER_USER[:email], TestConstants::SUPER_USER[:password]))
      response = get "/api/v1/services/index", {account_id: other_user.account_id, credentials: super_user.credentials}
      expect(response.status).to eq 200
      services_json = JSON.parse(response.body)
      expect(services_json.length).to eq 2
    end
    
  end
  
  context "Can change information about services" do
    
    it "Can create a new service" do
      session = {}
      user = UserObject.new(UserService.new.register(session, {user: unregistered_user}))

      service_in = service_hash(user.account_id)
      response = post("/api/v1/services/create", {credentials: user.credentials, service: service_in})
      expect(response.status).to eq 200
      return_json = JSON.parse(response.body)
      
      expect(return_json['name']).to eq service_in[:name]
      expect(return_json['code']).to eq service_in[:code]
      expect(return_json['account_id']).to eq user.account_id
      expect(return_json['description']).to eq service_in[:description]
    end
  end
  
  
  context "Networks can host one or more services" do
    it "Can create a new network" do
      session = {}
      user = UserObject.new(UserService.new.register(session, {user: unregistered_user}))
      
      network_in = network_hash(user.account_id)
      response = post("/api/v1/networks/create", {credentials: user.credentials, network: network_in})
      expect(response.status).to eq 200
      network_json = JSON.parse(response.body)
      
      # Create a couple services and add to network
      service_hashes = []
      (1..2).each do 
        service = service_hash(user['account_id'])
        service_hashes << service
        response = post "/api/v1/services/create", {service: service, credentials: session[:credentials]}
        expect(response.status).to eq 200
        service_json = JSON.parse(response.body)

        response = put("/api/v1/services/add_to_network", {credentials: user.credentials, service: service_json, network: network_json})
      end
    end
  end
  
end